# DerivAI — Indian Derivatives Strategy Builder

AI-powered options strategy builder for NSE. Type any instrument + capital and get 3 complete strategies instantly.

---

## 🚀 Deploy to GitHub Pages (Step by Step)

### Step 1 — Edit package.json
Open `package.json` and replace `YOUR_GITHUB_USERNAME` with your actual GitHub username:
```
"homepage": "https://YOUR_GITHUB_USERNAME.github.io/deriv-ai"
```

### Step 2 — Add your API key
Open `.env` and paste your Anthropic API key:
```
REACT_APP_ANTHROPIC_API_KEY=sk-ant-api03-xxxxxxxxxx
```
Get your key at: https://console.anthropic.com

### Step 3 — Install dependencies
```bash
npm install
```

### Step 4 — Create GitHub repo
Go to https://github.com/new
- Name: `deriv-ai`
- Keep it Public
- Click Create repository

### Step 5 — Push to GitHub
```bash
git init
git add .
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/deriv-ai.git
git push -u origin main
```

### Step 6 — Deploy to GitHub Pages
```bash
npm run deploy
```

✅ Your app will be live at:
```
https://YOUR_USERNAME.github.io/deriv-ai
```

---

## Run Locally
```bash
npm install
npm start
```
Opens at http://localhost:3000

---

## Project Structure
```
deriv-ai/
├── public/
│   └── index.html
├── src/
│   ├── index.js       ← entry point
│   ├── App.js         ← root component
│   └── DerivAI.jsx    ← main app
├── .env               ← your API key (never commit this)
├── .env.example       ← safe template to share
├── .gitignore         ← blocks .env from GitHub
└── package.json       ← includes gh-pages deploy script
```

---

## ⚠️ Disclaimer
Educational purposes only. Not SEBI-registered investment advice.
Options trading involves substantial risk of loss.
